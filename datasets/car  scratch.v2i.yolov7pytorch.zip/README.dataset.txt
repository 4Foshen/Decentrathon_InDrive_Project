# car  scratch > 2024-05-26 3:56pm
https://universe.roboflow.com/project-kmnth/car-scratch-xgxzs

Provided by a Roboflow user
License: CC BY 4.0

